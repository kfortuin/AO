return {
  [0] = function(c) return c == 1 and 1 or 2 end, -- plural
  ["traced %d instruction"] = {"traced %d instruction", "traced %d instructions"}, -- src\editor\debugger.lua
  ["%d instance"] = {"%d instance", "%d instances"}, -- src\editor\findreplace.lua
}
