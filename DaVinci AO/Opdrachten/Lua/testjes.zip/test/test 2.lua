for a = 1, 10 do

for i = 1, a do
  print( i .. "x" a.. "="  )
end

end

--[[hoofd
niet gelukt]]--