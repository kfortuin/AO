print("Wat is de code?")

answer = string.lower(io.read())

 if answer == "simsalabim" then
  print("De deur gaat open")
  
else 
  print("De deur gaat dicht")
  
end


--[hoofd]--