function color
  color = robot_arm: grab()
end